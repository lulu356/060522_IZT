﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _060522_IZT.DB_Model
{
    public static class DataBaseHelper
    {
        private static IZT_060522Entities _Entites = new IZT_060522Entities();
        public static List<Agent> GetAgents()
        {
            return _Entites.Agent.ToList();    
        }
        public static List<AgentType> GetAgentType()
        {
            return _Entites.AgentType.ToList();
        }

        public static void SaveChanges()
        {
            _Entites.SaveChanges();
        }

    }
}
