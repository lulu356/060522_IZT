﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;


namespace _060522_IZT.DB_Model
{
    public partial class Agent
    {
        public string ImagePath
        {
            get
            {
                var image = Logo;
                if (image is null)
                {
                    return "/Image/picture.png";
                }
                else
                {
                    var ImagePath = Directory.GetCurrentDirectory() + Logo.ToString();
                    return ImagePath;
                }

            }
        }
    }
}
