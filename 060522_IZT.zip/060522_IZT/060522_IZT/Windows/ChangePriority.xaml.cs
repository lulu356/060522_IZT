﻿using _060522_IZT.DB_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _060522_IZT.Windows
{
    public partial class ChangePriority : Window
    {
        private List<Agent> _AgentList;
        public ChangePriority(List<Agent> agents)
        {
            InitializeComponent();
            _AgentList = agents;
            NewPriorityTB.Text = _AgentList.Max(m => m.Priority).ToString();
        }

        private void ChangePriorityButton_Click(object sender, RoutedEventArgs e)
        {
            if (NewPriorityTB.Text.Length == 0)
            {
                MessageBox.Show("Необходимо ввести значение",
                   "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var newPriority = NewPriorityTB.Text;
            int intNewPriority = 0;
            try
            {
                intNewPriority = Convert.ToInt32(newPriority);
            }
            catch (Exception)
            {
                MessageBox.Show("Значение должно быть целым",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            foreach (var agent in _AgentList)
            {
                agent.Priority = Convert.ToInt32(NewPriorityTB.Text);
                DataBaseHelper.SaveChanges();
            }
            MessageBox.Show("Приоритет успешно изменен");
            this.Close();
        }
    }
}

