﻿using _060522_IZT.DB_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _060522_IZT.Windows
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class AgentListWindow : Window
    {
        private const int ItemsPerPage = 15;
        public AgentListWindow()
        {
            InitializeComponent();
            var AgentTypeList = DataBaseHelper.GetAgentType();
            AgentTypeList.Insert(0, new AgentType { Title = "Все" });
            FilterComboBox.ItemsSource = AgentTypeList;
            AgentListView.ItemsSource = DataBaseHelper.GetAgents();

        }

        public void UpdateAgentList()
        {
            if (SearchTextBox is null || SortComboBox is null || FilterComboBox is null)
                return;

            var Agent = DataBaseHelper.GetAgents();

            var allAgentCount = Agent.Count;

            if (SearchTextBox.Text.Length != 0)
            {
                Agent = Agent.Where(m => m.Email.Contains(SearchTextBox.Text) || m.Phone?.Contains(SearchTextBox.Text) == true).ToList();
            }
            switch (((ComboBoxItem)SortComboBox.SelectedItem).Content.ToString())
            {
                case "Наименование по возростанию":
                    Agent = Agent.OrderBy(m => m.Title).ToList();
                    break;
                case "Наименование по убыванию":
                    Agent = Agent.OrderByDescending(m => m.Title).ToList();
                    break;
                //case "Размер скидки по возрастанию":
                //    Agent = Agent.OrderBy(m => m.CountInStock).ToList();
                //    break;
                //case "Размер скидки по убыванию":
                //    Agent = Agent.OrderByDescending(m => m.CountInStock).ToList();
                //    break;
                case "Приоритет агента по возрастанию":
                    Agent = Agent.OrderBy(m => m.Priority).ToList();
                    break;
                case "Приоритет агента по убыванию":
                    Agent = Agent.OrderByDescending(m => m.Priority).ToList();
                    break;
            }
            if (((AgentType)FilterComboBox.SelectedItem).Title != "Все")
            {
                Agent = Agent.Where(m => m.AgentType == (AgentType)FilterComboBox.SelectedItem).ToList();
            }

            var fillteredAgentCount = Agent.Count;
            AgentCountTextBlock.Text = $"Выведено {fillteredAgentCount} из {allAgentCount}";

            AgentListView.ItemsSource = Agent;

            GenerateButton();

        }
        private void GenerateButton()
        {

            NumberButtonStackPanel.Children.Clear();
            int pageCount = Convert.ToInt32(Math.Floor((double)AgentListView.Items.Count / ItemsPerPage));
            var Agent = DataBaseHelper.GetAgents();
            for (int i = 0; i < 5; i++)
            {
                if (ItemsPerPage * i > Agent.Count)
                    continue;

                Button newButton = new Button()
                {
                    Content = i + 1,
                    Background = Brushes.Transparent,
                    Height = 25
                };
                newButton.Click += NewButton_Click;

                NumberButtonStackPanel.Children.Add(newButton);
            }

        }
        private void NewButton_Click(object sender, RoutedEventArgs e)
        {

        }
        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateAgentList();
        }

        private void SortTextBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateAgentList();
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateAgentList();
        }



        private void ChangePriorityClick(object sender, RoutedEventArgs e)
        {
            new ChangePriority(AgentListView.SelectedItems.Cast<Agent>().ToList()).ShowDialog();
            UpdateAgentList();

        }

        private void AgentListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView agentlListView = sender as ListView;

            if (agentlListView.SelectedItems.Count == 0)
            {
                ChangePriorityButton.Visibility = Visibility.Hidden;
            }
            else
            {
                ChangePriorityButton.Visibility = Visibility.Visible;
            }
        }
    }
}
